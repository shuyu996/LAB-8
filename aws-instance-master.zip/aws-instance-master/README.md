# Jupyter Notebooks

Welcome! Feel free to click on the notebooks to view them within GitHub or fork this repository so you can have your own copy. When submitting your assignment, please make sure your tutor has access to your Python code and datasets.

## Disclamer

Please note that this repository is private, and must remain private if you choose to use it or any of its contents. You cannot publically publish and/or distribute any content in this repository.
